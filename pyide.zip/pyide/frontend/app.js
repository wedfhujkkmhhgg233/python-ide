// Personal Python IDE — Phase 1 frontend.
// Vanilla JS, no build step, no framework. Every network call is deliberate
// and minimal (item 14/29): directory listings are one level at a time,
// file content is only fetched when a file is opened, and saves are
// debounced rather than sent on every keystroke.

const state = {
  currentProject: null, // {id, name}
  currentDir: "",       // relative dir currently listed
  currentFile: null,    // relative path of open file
  dirty: false,
};

const $ = (id) => document.getElementById(id);

async function api(path, options = {}) {
  const res = await fetch(path, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (res.status === 401) {
    showLogin();
    throw new Error("Not authenticated");
  }
  if (!res.ok) {
    let detail = "Request failed.";
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch (_) {}
    throw new Error(detail);
  }
  if (res.status === 204) return null;
  return res.json();
}

function showLogin() {
  $("app-view").classList.add("hidden");
  $("login-view").classList.remove("hidden");
}

function showApp() {
  $("login-view").classList.add("hidden");
  $("app-view").classList.remove("hidden");
  loadProjects();
}

// ---------- Auth ----------

$("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("login-error").textContent = "";
  try {
    await api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({
        username: $("login-username").value,
        password: $("login-password").value,
      }),
    });
    showApp();
  } catch (err) {
    $("login-error").textContent = err.message;
  }
});

$("logout-btn").addEventListener("click", async () => {
  await api("/api/auth/logout", { method: "POST" });
  showLogin();
});

// ---------- Drawer toggle ----------

$("menu-btn").addEventListener("click", () => {
  $("drawer").classList.toggle("hidden");
});

// ---------- Projects ----------

async function loadProjects() {
  const projects = await api("/api/projects");
  const list = $("project-list");
  list.innerHTML = "";
  projects.forEach((p) => {
    const li = document.createElement("li");
    li.textContent = p.name;
    li.addEventListener("click", () => openProject(p));
    list.appendChild(li);
  });
  $("project-list").classList.remove("hidden");
  $("file-panel").classList.add("hidden");
}

$("new-project-btn").addEventListener("click", async () => {
  const name = prompt("Project name:");
  if (!name) return;
  await api("/api/projects", { method: "POST", body: JSON.stringify({ name }) });
  loadProjects();
});

function openProject(project) {
  state.currentProject = project;
  state.currentDir = "";
  $("current-project-name").textContent = project.name;
  $("project-list").classList.add("hidden");
  $("file-panel").classList.remove("hidden");
  loadFiles();
}

$("back-to-projects-btn").addEventListener("click", () => {
  state.currentProject = null;
  loadProjects();
});

// ---------- Files ----------

async function loadFiles() {
  const entries = await api(
    `/api/projects/${state.currentProject.id}/files?path=${encodeURIComponent(state.currentDir)}`
  );
  const list = $("file-list");
  list.innerHTML = "";

  if (state.currentDir) {
    const up = document.createElement("li");
    up.textContent = "..";
    up.addEventListener("click", () => {
      state.currentDir = state.currentDir.split("/").slice(0, -1).join("/");
      loadFiles();
    });
    list.appendChild(up);
  }

  entries.forEach((entry) => {
    const li = document.createElement("li");
    li.className = entry.type;
    li.textContent = entry.name;
    const rel = state.currentDir ? `${state.currentDir}/${entry.name}` : entry.name;
    li.addEventListener("click", () => {
      if (entry.type === "dir") {
        state.currentDir = rel;
        loadFiles();
      } else {
        openFile(rel);
      }
    });
    list.appendChild(li);
  });
}

$("new-file-btn").addEventListener("click", async () => {
  const name = prompt("File name (e.g. main.py):");
  if (!name) return;
  const rel = state.currentDir ? `${state.currentDir}/${name}` : name;
  try {
    await api(`/api/projects/${state.currentProject.id}/files`, {
      method: "POST",
      body: JSON.stringify({ path: rel, type: "file", content: "" }),
    });
    loadFiles();
  } catch (err) {
    alert(err.message);
  }
});

$("new-folder-btn").addEventListener("click", async () => {
  const name = prompt("Folder name:");
  if (!name) return;
  const rel = state.currentDir ? `${state.currentDir}/${name}` : name;
  try {
    await api(`/api/projects/${state.currentProject.id}/files`, {
      method: "POST",
      body: JSON.stringify({ path: rel, type: "dir" }),
    });
    loadFiles();
  } catch (err) {
    alert(err.message);
  }
});

async function openFile(rel) {
  const data = await api(
    `/api/projects/${state.currentProject.id}/file?path=${encodeURIComponent(rel)}`
  );
  state.currentFile = rel;
  state.dirty = false;
  $("current-file").textContent = rel;
  $("editor").value = data.content;
  $("save-status").textContent = "Saved";
  $("drawer").classList.add("hidden"); // close drawer on mobile after opening a file
}

// ---------- Autosave (debounced, not per-keystroke) ----------

let saveTimer = null;
$("editor").addEventListener("input", () => {
  if (!state.currentFile) return;
  state.dirty = true;
  $("save-status").textContent = "Unsaved";
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveCurrentFile, 1200);
});

async function saveCurrentFile() {
  if (!state.currentFile || !state.dirty) return;
  try {
    await api(`/api/projects/${state.currentProject.id}/file`, {
      method: "PUT",
      body: JSON.stringify({ path: state.currentFile, content: $("editor").value }),
    });
    state.dirty = false;
    $("save-status").textContent = "Saved";
  } catch (err) {
    $("save-status").textContent = "Offline / Connection lost";
  }
}

window.addEventListener("beforeunload", (e) => {
  if (state.dirty) {
    e.preventDefault();
    e.returnValue = "";
  }
});

// ---------- Boot ----------

(async function boot() {
  try {
    await api("/api/auth/me");
    showApp();
  } catch (_) {
    showLogin();
  }
})();
