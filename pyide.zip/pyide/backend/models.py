from __future__ import annotations

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    username: str
    password: str


class ProjectCreateRequest(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class ProjectResponse(BaseModel):
    id: str
    name: str
    created_at: str
    modified_at: str


class EntryResponse(BaseModel):
    name: str
    type: str
    size: int


class CreatePathRequest(BaseModel):
    path: str
    type: str = Field(pattern="^(file|dir)$")
    content: str = ""


class WriteFileRequest(BaseModel):
    path: str
    content: str


class RenameRequest(BaseModel):
    old_path: str
    new_path: str
