from __future__ import annotations

from fastapi import Cookie, HTTPException, status

from .auth.security import get_session_username


def require_user(session: str | None = Cookie(default=None)) -> str:
    username = get_session_username(session)
    if not username:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated.")
    return username
