"""
Authentication primitives.

- Passwords are hashed with bcrypt (via passlib), never stored plaintext.
- Sessions are opaque random tokens; only their SHA-256 hash is stored in
  the DB (so a DB leak doesn't hand out valid session tokens directly).
- Login attempts are rate-limited per username to slow brute force.
"""
from __future__ import annotations

import hashlib
import secrets
import sys
from datetime import datetime, timedelta, timezone

from passlib.context import CryptContext

from .. import config
from ..db import db_cursor

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(plain_password: str) -> str:
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, password_hash: str) -> bool:
    if not password_hash:
        return False
    try:
        return pwd_context.verify(plain_password, password_hash)
    except ValueError:
        return False


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_session(username: str) -> str:
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(seconds=config.SESSION_MAX_AGE_SECONDS)
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO sessions (token_hash, username, created_at, expires_at) "
            "VALUES (?, ?, ?, ?)",
            (_hash_token(token), username, now.isoformat(), expires.isoformat()),
        )
    return token


def get_session_username(token: str | None) -> str | None:
    if not token:
        return None
    with db_cursor() as cur:
        cur.execute(
            "SELECT username, expires_at FROM sessions WHERE token_hash = ?",
            (_hash_token(token),),
        )
        row = cur.fetchone()
    if not row:
        return None
    expires_at = datetime.fromisoformat(row["expires_at"])
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if datetime.now(timezone.utc) > expires_at:
        invalidate_session(token)
        return None
    return row["username"]


def invalidate_session(token: str) -> None:
    with db_cursor() as cur:
        cur.execute("DELETE FROM sessions WHERE token_hash = ?", (_hash_token(token),))


def record_login_attempt(username: str, success: bool, ip: str | None) -> None:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO login_attempts (username, success, at, ip) VALUES (?, ?, ?, ?)",
            (username, int(success), datetime.now(timezone.utc).isoformat(), ip),
        )


def is_locked_out(username: str) -> bool:
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=config.LOGIN_LOCKOUT_SECONDS)
    with db_cursor() as cur:
        cur.execute(
            "SELECT success, at FROM login_attempts WHERE username = ? AND at > ? "
            "ORDER BY at DESC",
            (username, cutoff.isoformat()),
        )
        rows = cur.fetchall()
    recent_failures = 0
    for row in rows:
        if row["success"]:
            break
        recent_failures += 1
    return recent_failures >= config.MAX_LOGIN_ATTEMPTS


if __name__ == "__main__":
    # Convenience CLI: python -m backend.auth.security hash <password>
    if len(sys.argv) == 3 and sys.argv[1] == "hash":
        print(hash_password(sys.argv[2]))
    else:
        print("Usage: python -m backend.auth.security hash <password>")
