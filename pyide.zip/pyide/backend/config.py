"""
Environment-based configuration. No secrets or defaults for sensitive
values are hardcoded here — the app refuses to start with insecure
placeholder secrets in a production-like environment.
"""
from __future__ import annotations

import os
import secrets
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

# Where all project files physically live. Everything under this directory
# is the ONLY thing the filesystem layer is allowed to touch.
WORKSPACE_ROOT = Path(os.environ.get("WORKSPACE_ROOT", BASE_DIR / "workspace" / "projects"))
WORKSPACE_ROOT.mkdir(parents=True, exist_ok=True)

DB_PATH = Path(os.environ.get("DB_PATH", BASE_DIR / "workspace" / "ide.db"))

ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD_HASH = os.environ.get("ADMIN_PASSWORD_HASH", "")

ENV = os.environ.get("ENV", "development")
IS_PRODUCTION = ENV == "production"

# Session signing secret. In production this MUST be set explicitly via
# env var — we refuse to fall back to a random throwaway secret because that
# would invalidate all sessions on every restart and is a sign of
# misconfiguration.
SESSION_SECRET = os.environ.get("SESSION_SECRET", "")
if not SESSION_SECRET:
    if IS_PRODUCTION:
        raise RuntimeError(
            "SESSION_SECRET must be set via environment variable in production."
        )
    # Development-only convenience fallback (ephemeral, printed as a warning).
    SESSION_SECRET = secrets.token_hex(32)
    print(
        "[config] WARNING: SESSION_SECRET not set — using an ephemeral "
        "development secret. Set SESSION_SECRET in .env for real use."
    )

if IS_PRODUCTION and not ADMIN_PASSWORD_HASH:
    raise RuntimeError(
        "ADMIN_PASSWORD_HASH must be set via environment variable in production. "
        "Generate one with: python -m backend.auth.security hash <password>"
    )

SESSION_MAX_AGE_SECONDS = int(os.environ.get("SESSION_MAX_AGE_SECONDS", 60 * 60 * 12))  # 12h

MAX_LOGIN_ATTEMPTS = int(os.environ.get("MAX_LOGIN_ATTEMPTS", 5))
LOGIN_LOCKOUT_SECONDS = int(os.environ.get("LOGIN_LOCKOUT_SECONDS", 300))

MAX_FILE_BYTES = int(os.environ.get("MAX_FILE_BYTES", 2 * 1024 * 1024))  # 2 MB per file
MAX_PROJECT_COUNT = int(os.environ.get("MAX_PROJECT_COUNT", 100))
