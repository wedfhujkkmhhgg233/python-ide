"""
Workspace filesystem abstraction.

Every function here takes a project root (already validated by
security.path_security.safe_project_root) and a user-supplied relative path,
and every path is resolved through security.path_security.safe_join before
any real filesystem call happens. Do not add a filesystem call anywhere that
bypasses safe_join.
"""
from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from .. import config
from ..security.path_security import PathSecurityError, safe_join


class WorkspaceError(Exception):
    pass


@dataclass
class Entry:
    name: str
    type: str  # "file" | "dir"
    size: int


def create_file(project_root: Path, rel_path: str, content: str = "") -> None:
    target = safe_join(project_root, rel_path)
    if target.exists():
        raise WorkspaceError("File already exists.")
    if len(content.encode("utf-8")) > config.MAX_FILE_BYTES:
        raise WorkspaceError("File exceeds maximum allowed size.")
    target.parent.mkdir(parents=True, exist_ok=True)
    _assert_inside(project_root, target.parent)
    target.write_text(content, encoding="utf-8")


def create_folder(project_root: Path, rel_path: str) -> None:
    target = safe_join(project_root, rel_path)
    if target.exists():
        raise WorkspaceError("Folder already exists.")
    target.mkdir(parents=True, exist_ok=False)


def read_file(project_root: Path, rel_path: str) -> str:
    target = safe_join(project_root, rel_path)
    if not target.is_file():
        raise WorkspaceError("File not found.")
    return target.read_text(encoding="utf-8", errors="replace")


def write_file(project_root: Path, rel_path: str, content: str) -> None:
    target = safe_join(project_root, rel_path)
    if len(content.encode("utf-8")) > config.MAX_FILE_BYTES:
        raise WorkspaceError("File exceeds maximum allowed size.")
    if target.exists() and target.is_dir():
        raise WorkspaceError("Cannot write to a directory.")
    target.parent.mkdir(parents=True, exist_ok=True)
    _assert_inside(project_root, target.parent)
    target.write_text(content, encoding="utf-8")


def rename(project_root: Path, old_rel: str, new_rel: str) -> None:
    old_target = safe_join(project_root, old_rel)
    new_target = safe_join(project_root, new_rel)
    if not old_target.exists():
        raise WorkspaceError("Source path not found.")
    if new_target.exists():
        raise WorkspaceError("Destination already exists.")
    new_target.parent.mkdir(parents=True, exist_ok=True)
    _assert_inside(project_root, new_target.parent)
    old_target.rename(new_target)


def delete(project_root: Path, rel_path: str) -> None:
    target = safe_join(project_root, rel_path)
    if target == project_root.resolve():
        raise WorkspaceError("Cannot delete the project root.")
    if target.is_dir():
        shutil.rmtree(target)
    elif target.exists():
        target.unlink()
    else:
        raise WorkspaceError("Path not found.")


def list_directory(project_root: Path, rel_path: str = "") -> list[Entry]:
    if rel_path in ("", "."):
        target = project_root.resolve()
    else:
        target = safe_join(project_root, rel_path)
    if not target.is_dir():
        raise WorkspaceError("Directory not found.")
    entries = []
    for child in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
        try:
            size = child.stat().st_size if child.is_file() else 0
        except OSError:
            size = 0
        entries.append(
            Entry(name=child.name, type="dir" if child.is_dir() else "file", size=size)
        )
    return entries


def _assert_inside(project_root: Path, path: Path) -> None:
    """Extra defense-in-depth check after mkdir(parents=True)."""
    try:
        path.resolve().relative_to(project_root.resolve())
    except ValueError:
        raise PathSecurityError("Resolved path escapes the allowed workspace.")
