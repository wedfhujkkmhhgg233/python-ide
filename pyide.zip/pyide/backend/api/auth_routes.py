from __future__ import annotations

import logging

from fastapi import APIRouter, Cookie, Depends, HTTPException, Request, Response, status

from .. import config
from ..auth.security import (
    create_session,
    invalidate_session,
    is_locked_out,
    record_login_attempt,
    verify_password,
)
from ..deps import require_user
from ..models import LoginRequest

router = APIRouter(prefix="/api/auth", tags=["auth"])
logger = logging.getLogger("pyide.auth")


@router.post("/login")
def login(payload: LoginRequest, request: Request, response: Response):
    username = payload.username.strip()
    client_ip = request.client.host if request.client else None

    if is_locked_out(username):
        logger.warning("Login blocked (rate limited) for username=%s", username)
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many failed attempts. Try again later.",
        )

    valid_user = username == config.ADMIN_USERNAME
    valid_pass = verify_password(payload.password, config.ADMIN_PASSWORD_HASH) if valid_user else False
    success = valid_user and valid_pass

    record_login_attempt(username, success, client_ip)

    if not success:
        logger.info("Failed login attempt for username=%s", username)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials.")

    token = create_session(username)
    response.set_cookie(
        key="session",
        value=token,
        httponly=True,
        secure=config.IS_PRODUCTION,
        samesite="lax",
        max_age=config.SESSION_MAX_AGE_SECONDS,
    )
    logger.info("Successful login for username=%s", username)
    return {"username": username}


@router.post("/logout")
def logout(response: Response, session: str | None = Cookie(default=None)):
    if session:
        invalidate_session(session)
    response.delete_cookie("session")
    return {"ok": True}


@router.get("/me")
def me(username: str = Depends(require_user)):
    return {"username": username}
