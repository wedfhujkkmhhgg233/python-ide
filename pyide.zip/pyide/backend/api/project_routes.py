from __future__ import annotations

import shutil
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status

from .. import config
from ..db import db_cursor
from ..deps import require_user
from ..models import ProjectCreateRequest, ProjectResponse
from ..security.path_security import safe_project_root

router = APIRouter(prefix="/api/projects", tags=["projects"])


@router.get("", response_model=list[ProjectResponse])
def list_projects(username: str = Depends(require_user)):
    with db_cursor() as cur:
        cur.execute("SELECT id, name, created_at, modified_at FROM projects ORDER BY modified_at DESC")
        rows = cur.fetchall()
    return [dict(row) for row in rows]


@router.post("", response_model=ProjectResponse, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreateRequest, username: str = Depends(require_user)):
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) as c FROM projects")
        count = cur.fetchone()["c"]
    if count >= config.MAX_PROJECT_COUNT:
        raise HTTPException(status_code=400, detail="Maximum number of projects reached.")

    project_id = uuid.uuid4().hex[:16]
    now = datetime.now(timezone.utc).isoformat()

    project_root = safe_project_root(config.WORKSPACE_ROOT, project_id)
    project_root.mkdir(parents=True, exist_ok=False)

    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO projects (id, name, created_at, modified_at) VALUES (?, ?, ?, ?)",
            (project_id, payload.name.strip(), now, now),
        )

    return {"id": project_id, "name": payload.name.strip(), "created_at": now, "modified_at": now}


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(project_id: str, username: str = Depends(require_user)):
    project_root = safe_project_root(config.WORKSPACE_ROOT, project_id)
    with db_cursor() as cur:
        cur.execute("SELECT id FROM projects WHERE id = ?", (project_id,))
        if not cur.fetchone():
            raise HTTPException(status_code=404, detail="Project not found.")
        cur.execute("DELETE FROM projects WHERE id = ?", (project_id,))
    if project_root.exists():
        shutil.rmtree(project_root)
    return None
