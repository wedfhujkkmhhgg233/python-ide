from __future__ import annotations

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query

from .. import config
from ..db import db_cursor
from ..deps import require_user
from ..filesystem import workspace
from ..models import CreatePathRequest, EntryResponse, RenameRequest, WriteFileRequest
from ..security.path_security import PathSecurityError, safe_project_root

router = APIRouter(prefix="/api/projects/{project_id}", tags=["files"])
logger = logging.getLogger("pyide.files")


def _project_root_or_404(project_id: str):
    with db_cursor() as cur:
        cur.execute("SELECT id FROM projects WHERE id = ?", (project_id,))
        if not cur.fetchone():
            raise HTTPException(status_code=404, detail="Project not found.")
    return safe_project_root(config.WORKSPACE_ROOT, project_id)


def _touch_project(project_id: str) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE projects SET modified_at = ? WHERE id = ?",
            (datetime.now(timezone.utc).isoformat(), project_id),
        )


@router.get("/files", response_model=list[EntryResponse])
def list_files(project_id: str, path: str = "", username: str = Depends(require_user)):
    root = _project_root_or_404(project_id)
    try:
        entries = workspace.list_directory(root, path)
    except (workspace.WorkspaceError, PathSecurityError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    return [{"name": e.name, "type": e.type, "size": e.size} for e in entries]


@router.post("/files", status_code=201)
def create_path(project_id: str, payload: CreatePathRequest, username: str = Depends(require_user)):
    root = _project_root_or_404(project_id)
    try:
        if payload.type == "dir":
            workspace.create_folder(root, payload.path)
        else:
            workspace.create_file(root, payload.path, payload.content)
    except (workspace.WorkspaceError, PathSecurityError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    _touch_project(project_id)
    return {"ok": True}


@router.get("/file")
def read_file(project_id: str, path: str = Query(...), username: str = Depends(require_user)):
    root = _project_root_or_404(project_id)
    try:
        content = workspace.read_file(root, path)
    except (workspace.WorkspaceError, PathSecurityError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"path": path, "content": content}


@router.put("/file")
def write_file(project_id: str, payload: WriteFileRequest, username: str = Depends(require_user)):
    root = _project_root_or_404(project_id)
    try:
        workspace.write_file(root, payload.path, payload.content)
    except (workspace.WorkspaceError, PathSecurityError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    _touch_project(project_id)
    return {"saved": True, "modified_at": datetime.now(timezone.utc).isoformat()}


@router.delete("/file")
def delete_path(project_id: str, path: str = Query(...), username: str = Depends(require_user)):
    root = _project_root_or_404(project_id)
    try:
        workspace.delete(root, path)
    except (workspace.WorkspaceError, PathSecurityError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    _touch_project(project_id)
    return {"ok": True}


@router.post("/file/rename")
def rename_path(project_id: str, payload: RenameRequest, username: str = Depends(require_user)):
    root = _project_root_or_404(project_id)
    try:
        workspace.rename(root, payload.old_path, payload.new_path)
    except (workspace.WorkspaceError, PathSecurityError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    _touch_project(project_id)
    return {"ok": True}
