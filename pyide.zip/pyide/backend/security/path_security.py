"""
Central path-security module.

RULE: Every filesystem operation that touches a user-supplied path MUST go
through safe_join() in this file. Nowhere else in the codebase should a
filesystem path be built from request input.

Defends against:
- ../ traversal
- absolute path injection
- symlink escape (resolved via realpath, checked AFTER resolution)
- null-byte / unusual character tricks
"""
from __future__ import annotations

import os
import re
from pathlib import Path

# Only allow simple, boring path segments: letters, numbers, dot, dash,
# underscore, and forward slash as a separator. No leading dot-dot segments.
_SEGMENT_RE = re.compile(r"^[A-Za-z0-9._\-]+$")


class PathSecurityError(ValueError):
    """Raised whenever a requested path would escape its allowed root."""


def _validate_segments(relative_path: str) -> list[str]:
    if relative_path is None:
        raise PathSecurityError("Path is required.")

    # Reject null bytes outright — some filesystems / C libraries treat
    # embedded NULs specially and it's never legitimate here.
    if "\x00" in relative_path:
        raise PathSecurityError("Invalid path.")

    normalized = relative_path.replace("\\", "/")

    # Explicitly reject absolute paths (POSIX leading '/' or a Windows drive
    # letter like 'C:/'). Without this check, a leading '/' would just be
    # silently stripped by the empty-segment filter below and treated as
    # relative — which happens to stay inside root but is misleading and
    # violates the "never accept an absolute path" requirement outright.
    if normalized.startswith("/") or re.match(r"^[A-Za-z]:", normalized):
        raise PathSecurityError("Absolute paths are not allowed.")

    # Normalize separators, split, and reject empty/"." / ".." segments.
    raw_segments = normalized.split("/")
    segments = [s for s in raw_segments if s not in ("", ".")]

    if any(s == ".." for s in segments):
        raise PathSecurityError("Path traversal is not allowed.")

    for s in segments:
        if not _SEGMENT_RE.match(s):
            raise PathSecurityError(f"Invalid character in path segment: {s!r}")

    if not segments:
        raise PathSecurityError("Path is required.")

    return segments


def safe_join(root: Path, relative_path: str) -> Path:
    """
    Resolve `relative_path` against `root` and guarantee the result stays
    inside `root`, even in the presence of symlinks.

    Raises PathSecurityError if the resulting path would escape root.
    """
    root_resolved = root.resolve()
    segments = _validate_segments(relative_path)

    candidate = root_resolved.joinpath(*segments)

    # Resolve symlinks etc. NOTE: for a path that doesn't exist yet (e.g. a
    # file we are about to create), resolve() still normalizes '..' and
    # symlinks in the existing parent portion, which is what we need.
    resolved = candidate.resolve()

    try:
        resolved.relative_to(root_resolved)
    except ValueError:
        raise PathSecurityError("Resolved path escapes the allowed workspace.")

    return resolved


def safe_project_root(workspace_root: Path, project_id: str) -> Path:
    """Validate a project_id (used as a directory name) and return its root."""
    if not re.match(r"^[A-Za-z0-9_\-]{1,64}$", project_id or ""):
        raise PathSecurityError("Invalid project id.")
    root = (workspace_root / project_id).resolve()
    workspace_resolved = workspace_root.resolve()
    try:
        root.relative_to(workspace_resolved)
    except ValueError:
        raise PathSecurityError("Invalid project id.")
    return root
