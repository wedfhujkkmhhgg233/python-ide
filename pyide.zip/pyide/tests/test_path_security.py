"""
Filesystem security tests (item 33). Pure stdlib — no FastAPI/pytest
dependency required to run: `python3 tests/test_path_security.py`.
"""
import importlib.util
import os
import sys
import tempfile
from pathlib import Path

_THIS_DIR = Path(__file__).resolve().parent
_MODULE_PATH = _THIS_DIR.parent / "backend" / "security" / "path_security.py"

spec = importlib.util.spec_from_file_location("path_security", _MODULE_PATH)
ps = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ps)


def make_root():
    root = Path(tempfile.mkdtemp())
    (root / "sub").mkdir()
    (root / "sub" / "a.txt").write_text("hi")
    return root


def expect(condition, message):
    if not condition:
        raise AssertionError(message)
    print(f"PASS: {message}")


def test_normal_paths_allowed():
    root = make_root()
    ps.safe_join(root, "sub/a.txt")
    ps.safe_join(root, "normal_file-1.py")
    ps.safe_join(root, "nested/dir/file.py")
    expect(True, "normal relative paths are accepted")


def test_dot_dot_traversal_blocked():
    root = make_root()
    for bad in ["../etc/passwd", "sub/../../etc/passwd", "../../../../etc/shadow"]:
        try:
            ps.safe_join(root, bad)
            raise AssertionError(f"traversal not blocked: {bad}")
        except ps.PathSecurityError:
            pass
    expect(True, "'..' traversal is blocked")


def test_absolute_paths_blocked():
    root = make_root()
    for bad in ["/etc/passwd", "/root/.ssh/id_rsa", "C:/Windows/System32"]:
        try:
            ps.safe_join(root, bad)
            raise AssertionError(f"absolute path not blocked: {bad}")
        except ps.PathSecurityError:
            pass
    expect(True, "absolute paths are blocked")


def test_null_byte_blocked():
    root = make_root()
    try:
        ps.safe_join(root, "a\x00.txt")
        raise AssertionError("null byte not blocked")
    except ps.PathSecurityError:
        pass
    expect(True, "null bytes are blocked")


def test_symlink_escape_blocked():
    root = make_root()
    outside = Path(tempfile.mkdtemp())
    (outside / "secret.txt").write_text("secret")
    link = root / "sub" / "escape"
    try:
        os.symlink(outside, link)
    except OSError:
        print("SKIP: symlink test (no permission in this environment)")
        return
    try:
        ps.safe_join(root, "sub/escape/secret.txt")
        raise AssertionError("symlink escape not blocked")
    except ps.PathSecurityError:
        pass
    expect(True, "symlink escape outside workspace is blocked")


def test_invalid_project_id_blocked():
    root = make_root()
    for bad in ["../evil", "/etc", "proj/../../etc"]:
        try:
            ps.safe_project_root(root, bad)
            raise AssertionError(f"invalid project id not blocked: {bad}")
        except ps.PathSecurityError:
            pass
    ps.safe_project_root(root, "abc123-project")
    expect(True, "invalid project ids are blocked, valid ones pass")


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
    print(f"\n{len(tests)} test functions completed successfully.")
